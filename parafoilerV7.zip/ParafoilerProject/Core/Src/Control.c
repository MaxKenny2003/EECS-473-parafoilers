#include "stm32h7xx_hal.h"
#include "Control.h"
#include <stdio.h>
#include <math.h>

#define DEG_TO_RAD (M_PI / 180.0)
#define RAD_TO_DEG (180.0 / M_PI)

double calc_angle(float target_long, float target_lat, float current_long, float current_lat) {
    // Convert to radians
    double lat1 = current_lat * DEG_TO_RAD;
    double lon1 = current_long * DEG_TO_RAD;
    double lat2 = target_lat * DEG_TO_RAD;
    double lon2 = target_long * DEG_TO_RAD;

    // Compute difference in longitude
    double dLon = lon2 - lon1;

    // Compute bearing
    double x = sin(dLon) * cos(lat2);
    double y = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon);

    double bearing = atan2(x, y); // result in radians
    double bearing_deg = fmod((bearing * RAD_TO_DEG + 360.0), 360.0); // convert to 0–360°

    return bearing_deg;
}
