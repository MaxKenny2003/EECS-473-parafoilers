#ifndef INC_NEO_M9_H_
#define INC_NEO_M9_H_

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "stm32h7xx_hal.h"

typedef struct GPS_Data{
	float longitude;
	float latitude;
	float altitude;
	float ground_speed;
}GPS_Info;

/**
  * @brief checks if the GPS device is ready on the I2C bus
  * @param hi2c: pointer to a I2C_HandleTypeDef structure that contains
  * the configuration information for the specified I2C
  * @retval HAL_StatusTypeDef: HAL_OK if device is ready, otherwise error code
  */
HAL_StatusTypeDef initialize_GPS(I2C_HandleTypeDef *hi2c);


/**
  * @brief Reads a block of data from the GPS and finds the GNGGA message.
  * @param hi2c pointer to a I2C_HandleTypeDef structure that contains
  * the configuration information for the specified I2C
  * @retval char*: pointer to the isolated string, or NULL if not found
  */
GPS_Info read_GPS_message(I2C_HandleTypeDef *hi2c);

GPS_Info parse_usefuldata_from_NMEA(char* NMEA_String, char type_of_string);


#endif /* INC_NEO_M9_H_ */
