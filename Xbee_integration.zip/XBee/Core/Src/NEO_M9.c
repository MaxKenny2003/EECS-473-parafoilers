#include "NEO_M9.h"


/* Defining the programs for the driver */

static uint8_t gps_rx_buffer[256];

/**
  * @brief Checks if the GPS device is ready on the I2C bus
  * @param hi2c: ptr to a I2C_HandleTypeDef structure
  * @retval HAL_StatusTypeDef: HAL_OK if device is ready, otherwise error code
  */
HAL_StatusTypeDef initialize_GPS(I2C_HandleTypeDef *hi2c)
{
	// printf moved to main because you cant printf here
	if (HAL_I2C_IsDeviceReady(hi2c, (0x42 << 1), 2, 100) == HAL_OK)
	{
		return HAL_OK;
	}
	else
	{
		return HAL_ERROR;
	}
}

/**
  * @brief Reads a block of data from the GPS and finds the GNGGA message
  * @param hi2c: ptr to a I2C_HandleTypeDef structure.
  * @retval char*: pointer to the isolated string, or NULL if not found
  */
GPS_Info read_GPS_message(I2C_HandleTypeDef *hi2c)
{
	uint8_t bytes_available_buffer[2];
	uint16_t bytes_to_read = 0;
	GPS_Info temp_GPS_Struct;

	// Read how many bytes are available
	if (HAL_I2C_Mem_Read(hi2c, (0x42 << 1), 0xFD, I2C_MEMADD_SIZE_8BIT, bytes_available_buffer, 2, 100) == HAL_OK)
	{
	    bytes_to_read = bytes_available_buffer[0] | (bytes_available_buffer[1] << 8);
	    //printf("DEBUG - Bytes available: %u\r\n", bytes_to_read);

	    if (bytes_to_read > 0)
	    {
	        // Limit how much we read to avoid buffer overflow
	        if (bytes_to_read > sizeof(gps_rx_buffer))
	            bytes_to_read = sizeof(gps_rx_buffer);

	        // Read from 0xFF register — this is where the actual data is stored
	        if (HAL_I2C_Mem_Read(hi2c, (0x42 << 1), 0xFF, I2C_MEMADD_SIZE_8BIT, gps_rx_buffer, bytes_to_read, 500) == HAL_OK)
	        {
	            gps_rx_buffer[bytes_to_read] = '\0';

	            // Print first few bytes as hex to debug
	            //printf("DEBUG - First bytes (hex): ");
	            for (int i = 0; i < (bytes_to_read > 50 ? 50 : bytes_to_read); i++)
	            {
	                //printf("%02X ", gps_rx_buffer[i]);
	            }
	            //printf("\r\n");

	            // Try to print as string (in case it’s ASCII NMEA)
	            //printf("DEBUG - As string: %s\r\n", gps_rx_buffer);

	            // Look for "$GNGGA" within the received data
	            char* gngga_ptr = strstr((char*)gps_rx_buffer, "$GNGGA");

	            if (gngga_ptr != NULL)
	            {
	                char* end_ptr = strchr(gngga_ptr, '\r');
	                if (end_ptr != NULL)
	                {
	                    *end_ptr = '\0'; // terminate the string at the end of the sentence
	                    temp_GPS_Struct = parse_usefuldata_from_NMEA(gngga_ptr, 'G');
	                    return temp_GPS_Struct; // return pointer to the found sentence
	                }
	            }


//	            char* gnrmc_ptr = strstr((char*)gps_rx_buffer, "$GNRMC");
//
//	            if(gnrmc_ptr != NULL)
//	            {
//	            	char* end_ptr = strchr(gnrmc_ptr, '\r');
//	            	if(end_ptr != NULL)
//	            	{
//	            		*end_ptr = '\0';
//	            		temp_GPS_Struct = parse_usefuldata_from_NMEA(gnrmc_ptr, 'M');
//	            		return temp_GPS_Struct;
//	            	}
//	            }

	        }
	        else
	        {
	            printf("ERROR - Failed to read data from GPS buffer (0xFF)\r\n");
	        }
	    }
	}
	else
	{
	    printf("ERROR - Failed to read bytes available register (0xFD)\r\n");
	}

	return temp_GPS_Struct;
}

GPS_Info parse_usefuldata_from_NMEA(char* NMEA_String, char type_of_string)
{
	// $GNGGA,010257.00,4217.56915,N,08342.72693,W,1,12,0.93,266.3,M,-34.7,M,,*7E
	char *token;
	int field = 0;
	GPS_Info temp_GPS_Struct;
	float NMEAlat;
	float NMEAlon;

	char sentence[128];
	strcpy(sentence, NMEA_String);
	sentence[sizeof(sentence) - 1] = '\0';

	token = strtok(sentence, ",");
	if(type_of_string == 'G')
	{
		while (token != NULL) {
			    if (field == 2) {
			        // Latitude
			        NMEAlat = atof(token);
			        int degrees = (int)(NMEAlat / 100);      // 42
			        float minutes = NMEAlat - (degrees*100); // 17.67935
			        temp_GPS_Struct.latitude = degrees + (minutes / 60.0); // 42.294656
			    } else if (field == 3) {
			        // N/S
			        if (token[0] == 'S') temp_GPS_Struct.latitude = -temp_GPS_Struct.latitude;
			    } else if (field == 4) {
			        // Longitude
			        NMEAlon = atof(token);
			        int degrees = (int)(NMEAlon / 100);      // 42
					float minutes = NMEAlon - (degrees*100); // 17.67935
					temp_GPS_Struct.longitude = degrees + (minutes / 60.0); // 42.294656
			    } else if (field == 5) {
			        // E/W
			        if (token[0] == 'W') temp_GPS_Struct.longitude = -temp_GPS_Struct.longitude;
			    }
			    else if (field == 9)
			    {
			    	temp_GPS_Struct.altitude = atof(token);
			    }

			    token = strtok(NULL, ",");
			    field++;
			}
			printf("xxxxxxxLatitude: %.6f \r\n", temp_GPS_Struct.latitude);
			printf("xxxxxLongitude: %.6f \r\n", temp_GPS_Struct.longitude);
			printf("xxxxxxAltitude: %.6f \r\n", temp_GPS_Struct.altitude);
	}
	if(type_of_string == 'M')
	{
		while (token != NULL) {
					    if (field == 8) {
					        // Latitude
					    	temp_GPS_Struct.ground_speed = atof(token);
					    }
					    token = strtok(NULL, ",");
					    field++;
					}
			//printf("Ground Speed: %.6f \r\n", groundSpeed);
	}

	return temp_GPS_Struct;
}
